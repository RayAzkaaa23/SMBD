<style>
    body {
        background-color: #f2f2f2;
    }
    .teks {
      position: absolute;
      top: 250px;
      left: 200px;
      font-family: sans-serif;
      font-size: 20px;
    }
    .form {
        position: absolute;
        top: -30px;
        left: 590px;
        width: 90%;
        height: 150%;
        margin: 0 auto;
        box-shadow: 0px 0px 10px #bbbbbb;
        padding: 20px;
        box-sizing: border-box;
        font-family: sans-serif;
        background-color: white;
        }
        label {
            position: absolute;
            top: 16px;
            left: 16px;
            color: #aaa;
        
    }
    .input-container {
        width: 50%;
        }
      
        input[type="email"] {
            width: 200%;
            height: 60px;
            padding: 12px 20px;
            margin: 10px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        
        input[type="password"] {
            width: 400%;
            height: 60px;
            padding: 12px 20px;
            margin: 10px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
      
        input[type="submit"] {
            width: 400%;
            height: 60px;        
            padding: 12px 20px;
            margin: 12px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-family: sans-serif;
            font-size: 20px;
            color: white;
        }
        label {
            position: absolute;
            top: 16px;
            left: 16px;
            color: #aaa;
    }
    </style><?php /**PATH C:\xampp\htdocs\TestLaravel\resources\views/layout/aplikasi.blade.php ENDPATH**/ ?>