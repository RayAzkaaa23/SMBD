<style>
body {
    background-color: #f2f2f2;
}
.teks {
  text-align: center;
  font-family: sans-serif;
  font-size: 20px;
}
.form {
    position: absolute;
    top: 120px;
    left: 440px;
    width: 40%;
    height: 80%;
    margin: 0 auto;
    box-shadow: 0px 0px 10px #bbbbbb;
    padding: 20px;
    box-sizing: border-box;
    font-family: sans-serif;
    background-color: white;
    }
    label {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #aaa;
    
}
.input-container {
    width: 50%;
    }
  
    input[type="text"] {
        width: 200%;
        height: 60px;
        padding: 12px 20px;
        margin: 10px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    input[type="email"] {
        width: 200%;
        height: 60px;
        padding: 12px 20px;
        margin: 10px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    
    input[type="password"] {
        width: 400%;
        height: 60px;
        padding: 12px 20px;
        margin: 10px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
  
    input[type="submit"] {
        width: 400%;
        height: 60px;        
        padding: 12px 20px;
        margin: 12px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
        background-color: #0099cc;
        font-family: sans-serif;
        font-size: 20px;
        color: white;
    }
    label {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #aaa;
}
</style>

<div class="form">
  <div class="teks">
    <h1 style="color:#0099cc">Registrasi OnlyFrendsz</h1>
    <h3>Buat akun OnlyFrensz</h3>
    <h3>Bergabunglah dengan yang lainnya</h3>

    <form action="/sesi/buat" method="post">
      <?php echo csrf_field(); ?>
        <div class="input-container">
          <input type="text" value="<?php echo e(Session::get('username')); ?>" name="username" placeholder="Buat Username" id="username" required>
          <input type="email" value="<?php echo e(Session::get('email')); ?>" name="email" placeholder="Email" id="email" required>

        <div class="input-container">
          <input type="password" name="password" placeholder="Buat Password" id="password" required>
    </form>    
        <input type="submit" value="Daftar">
    </form><?php /**PATH C:\xampp\htdocs\TestLaravel\resources\views/sesi/daftar.blade.php ENDPATH**/ ?>