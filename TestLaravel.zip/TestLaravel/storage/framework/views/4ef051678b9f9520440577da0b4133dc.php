<!DOCTYPE HTML>
<html>
    <head>
        <title>Halaman Login</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <style>
    .container{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    padding: 20px 25px;
    width: 300px;

    background-color: #8ebf42;
    box-shadow: 0 0 10px rgba(255,255,255,.3);
    }
    </style>

    <body>
        <div class="container">
          <h1>Register</h1>
            <form action="/ya/Masuk" method="post">
            <?php echo csrf_field(); ?>
                <label>Nama Lengkap</label>
                <br>
                <input type="text" value="<?php echo e(Session::get('username')); ?>" name="username" placeholder="Nama Lengap" id="username" required>
                <br>
                <label>NIP</label>
                <br>
                <input type="text" value="<?php echo e(Session::get('nip')); ?>" name="nip" placeholder="NIP" id="username" required>
                <br>
                <label>Email</label>
                <br>
                <input type="email" value="<?php echo e(Session::get('email')); ?>" name="email" placeholder="Email" id="email" required>
                <br>
                <label>Password</label>
                <br>
                <input type="password" name="password" placeholder="Buat Password" id="password" required>
                <br>
                <button action="/ya/Masuk" type="submit">Daftar</button>
                <p> Sudah punya akun?
                  <a href="/ya/Masuk">Login di sini</a>
                </p>
            </form>
        </div>
    </body>
</html>

<?php /**PATH C:\xampp\htdocs\TestLaravel\resources\views/ya/registrasi.blade.php ENDPATH**/ ?>