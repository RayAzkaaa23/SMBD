<style>
body {
    background-color: #f2f2f2;
}
.teks {
position: absolute;
top: 250px;
left: 200px;
font-family: sans-serif;
font-size: 20px;
}
.form {
    position: absolute;
    top: -30px;
    left: 590px;
    width: 90%;
    height: 150%;
    margin: 0 auto;
    box-shadow: 0px 0px 10px #bbbbbb;
    padding: 20px;
    box-sizing: border-box;
    font-family: sans-serif;
    background-color: white;
    }
    label {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #aaa;

}
.input-container {
    width: 50%;
    }

    input[type="email"] {
        width: 200%;
        height: 60px;
        padding: 12px 20px;
        margin: 10px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 10px;
    }
    input[type="password"] {
        width: 400%;
        height: 60px;
        padding: 12px 20px;
        margin: 10px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    input[type="submit"] {
        width: 400%;
        height: 60px;        
        padding: 12px 20px;
        margin: 12px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 10px;
        font-family: sans-serif;
        font-size: 20px;
        color: white;
    }
    label {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #aaa;
}
</style>
<div class="teks">
<h1 style="color:#0099cc">OnlyFrendsz</h1>
<h3>OnlyFrendsz bisa membantumu terkoneksi</h3>
<h3>dan berbagi dengan orang yang kamu kenal</h3>
<h3>maupun tidak.</h3>
<div class="form">
    <?php if(isset($success)): ?>
        <h6 style="position: fixed; top: 200px; left: 970px; color: #76BA1B;"><?php echo e($success); ?></h6>
    <?php endif; ?>

    <form action="/sesi/login" method="post">
        <?php echo csrf_field(); ?>
        <div class="input-container">
            <input type="email" name="email" placeholder="Email" id="email" required>
        <div class="input-container">
            <input type="password" name="password" placeholder="Password" id="password" required>
            
        <input type="submit" value="Masuk" style="background-color:#0099cc">
    </form>    
    <form action="/sesi/daftar" method="get">
        <input type="submit" value="Daftar" style="background-color:#76BA1B">
    </form><?php /**PATH C:\xampp\htdocs\TestLaravel\resources\views/sesi/index.blade.php ENDPATH**/ ?>