<style>
body {
    background-color: #f2f2f2;
}
.teks {
  text-align: center;
  font-family: sans-serif;
  font-size: 20px;
}
.form {
    position: absolute;
    top: 120px;
    left: 440px;
    width: 40%;
    height: 70%;
    margin: 0 auto;
    box-shadow: 0px 0px 10px #bbbbbb;
    padding: 20px;
    box-sizing: border-box;
    font-family: sans-serif;
    background-color: white;
    }
    label {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #aaa;
    
}
.input-container {
    width: 50%;
    }
  
    input[type="text"] {
        width: 200%;
        height: 60px;
        padding: 12px 20px;
        margin: 10px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    
    input[type="password"] {
        width: 400%;
        height: 60px;
        padding: 12px 20px;
        margin: 10px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
  
    input[type="submit"] {
        width: 400%;
        height: 60px;        
        padding: 12px 20px;
        margin: 12px 0;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
        background-color: #0099cc;
        font-family: sans-serif;
        font-size: 20px;
        color: white;
    }
    label {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #aaa;
}
</style>

<div class="form">
<div class="teks">
<h1 style="color:#0099cc">Selamat Datang di OnlyFrendsz</h1>
<h3>tugas ini sudah selesai</h3>
<h3>UAS sudah selesai</h3>

    <form action="https://www.youtube.com/watch?v=Z88m3vI1zHg&t=14s" method="post">
        <div class="input-container">
        <div class="input-container">
            <input type="submit" value="klik untuk rehat" style="background-color:green"> 
    </form>
    <form action="/sesi/logout" method="get">
        <input type="submit" value="Logout" style="background-color:red">
    </form><?php /**PATH C:\xampp\htdocs\TestLaravel\resources\views/sesi/login.blade.php ENDPATH**/ ?>