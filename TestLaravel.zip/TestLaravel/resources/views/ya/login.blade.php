<!DOCTYPE html>
<html lang=en>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Status Kehadiran</title>
<style>
body {
    background-color: #f2f2f2;
}
.teks {
  text-align: center;
  font-family: sans-serif;
  font-size: 20px;
}
.form {
    position: absolute;
    top: 120px;
    left: 440px;
    width: 40%;
    height: 70%;
    margin: 0 auto;
    box-shadow: 0px 0px 10px #bbbbbb;
    padding: 20px;
    box-sizing: border-box;
    font-family: sans-serif;
    background-color: white;
    }
    label {
        position: absolute;
        top: 16px;
        left: 16px;
        color: #aaa;
    
}
</style>
</head>
<body>
    <div class="form">
        <div class="teks">
            <h1 style="color:#0099cc">Login Berhasil</h1>
            <h3>Kehadiran Tercatat</h3>
            <form action="/ya/logout" method="get">
                <input type="submit" value="Logout" style="background-color:red">
            </form>
</body>
</html>