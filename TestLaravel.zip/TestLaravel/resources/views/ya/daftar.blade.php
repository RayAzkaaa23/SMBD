<!DOCTYPE html>
<html lang=en>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kehadiran ASN</title>
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<style>
html, body {
    display: flex;
    justify-content: center;
    font-family: Roboto, Arial, sans-serif;
    font-size: 15px;
    }
form {
    border: 5px solid #f1f1f1;
    }
input[type=text], input[type=password], input[type=email] {
    width: 100%;
    padding: 16px 8px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    }
button {
    background-color: #8ebf42;
    color: white;
    padding: 14px 0;
    margin: 10px 0;
    border: none;
    cursor: grabbing;
    width: 100%;
    }
h1 {
    text-align:center;
    font-size:18;
    }
button:hover {
    opacity: 0.8;
    }
.formcontainer {
    text-align: left;
    margin: 24px 50px 12px;
    }
.container {
    padding: 16px 0;
    text-align:left;
    }
span.psw {
    float: right;
    padding-top: 0;
    padding-right: 15px;
    }
</style>
<body>
<form action="/ya/buat" method="post">
    @csrf
    <h1>Registrasi</h1>
    <div class="formcontainer">
    <hr/>
    <div class="container">
        <input type="text" value="{{Session::get('username')}}" name="username" placeholder="NIP" id="username" required>
        <div class="container">
        <input type="email" value="{{Session::get('email')}}" name="email" placeholder="Email" id="email" required>
        <input type="password" name="password" placeholder="Buat Password" id="password" required>
        <button type="submit">Daftar</button>
    </div>
</form>
</body>
</html>
