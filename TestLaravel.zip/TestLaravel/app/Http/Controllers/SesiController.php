<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class SesiController extends Controller
{
    function index()
    {
        return view("ya/index");
    }
    function login(request $request)
    {
        Session::flash("username", $request->username);
        $infologin = [
            "name"=>$request->username,
            "password"=>$request->password

        ];

        if(Auth::attempt($infologin)){
            return view("ya/login");
        } 
        else{
            return view("ya/salah");
        }
    }
    function daftar()
    {
        return view("ya/daftar");
    }
    function buat(Request $request)
    {
        Session::flash("username", $request->username);
        $data = [
            "name"=>$request->username,
            "email"=>$request->email,
            "password"=>$request->password
        ];
        User::create($data);
        $infologin = [
            "name"=>$request->username,
            "password"=>Hash::make($request->password)

        ];

        if(Auth::attempt($data)){
            return view("ya/index")->with('success',"NIP anda berhasil didaftarkan");
        } 
        else{
            return view("ya/daftar");
        }
    }
    function logout(){
        Auth::logout();
        return view("ya/index");
    }
}
