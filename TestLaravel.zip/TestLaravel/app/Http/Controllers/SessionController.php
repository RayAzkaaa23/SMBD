<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class SessionController extends Controller
{
    function index()
    {
        return view("sesi/index");
    }
    function login(request $request)
    {
        Session::flash("email", $request->email);
        $infologin = [
            "email"=>$request->email,
            "password"=>$request->password

        ];

        if(Auth::attempt($infologin)){
            return view("sesi/login");
        } 
        else{
            return view("sesi/salah");
        }
    }
    function daftar()
    {
        return view("sesi/daftar");
    }
    function buat(Request $request)
    {
        Session::flash("username", $request->username);
        Session::flash("email", $request->email);

        $data = [
            "name"=>$request->username,
            "email"=>$request->email,
            "password"=>$request->password
        ];
        User::create($data);
        $infologin = [
            "email"=>$request->email,
            "password"=>Hash::make($request->password)

        ];

        if(Auth::attempt($data)){
            return view("sesi/index")->with('success',"Berhasil Daftar");
        } 
        else{
            return view("sesi/daftar");
        }
    }
    function logout(){
        Auth::logout();
        return view("sesi/index");
    }
}
