<?php

use App\Http\Controllers\SesiController;
use App\Http\Controllers\SessionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get("/sesi", [SessionController::class, "index"]);
Route::post("/sesi/login", [SessionController::class, "login"]);
Route::get("/sesi/daftar", [SessionController::class, "daftar"]);
Route::get("/sesi/logout", [SessionController::class, "logout"]);
Route::post("/sesi/buat", [SessionController::class, "buat"]);


Route::get("ya", [SesiController::class, "index"]);
Route::post("/ya/login", [SesiController::class, "login"]);
Route::get("/ya/daftar", [SesiController::class, "daftar"]);
Route::get("/ya/logout", [SesiController::class, "logout"]);
Route::post("/ya/buat", [SesiController::class, "buat"]);


